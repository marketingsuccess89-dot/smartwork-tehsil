﻿Smart Typing PC Sync Agent
===========================

1. How to run PC Sync Agent:
   - Double-click "SmartTyping_Agent.exe"
   - Enter your Gmail and PIN to link your MS Word with mobile scanner.

2. How to install MS Word Add-in (Optional):
   - Right-click "setup.bat" and choose "Run as administrator" (or double-click).
   - Open Microsoft Word -> Insert tab -> My Add-ins -> Developer Add-ins -> Smart Typing.
